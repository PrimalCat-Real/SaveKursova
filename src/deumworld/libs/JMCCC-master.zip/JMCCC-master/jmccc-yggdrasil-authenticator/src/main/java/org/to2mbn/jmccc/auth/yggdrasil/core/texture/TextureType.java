package org.to2mbn.jmccc.auth.yggdrasil.core.texture;

public enum TextureType {

	SKIN,
	CAPE,
	ELYTRA;

}

package org.to2mbn.jmccc.mcdownloader.provider;

public interface DownloadInfoProcessor {

	String process(String uri);

}

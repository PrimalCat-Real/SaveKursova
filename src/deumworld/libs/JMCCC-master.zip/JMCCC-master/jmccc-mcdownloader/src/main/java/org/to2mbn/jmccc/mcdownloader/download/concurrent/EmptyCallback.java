package org.to2mbn.jmccc.mcdownloader.download.concurrent;

class EmptyCallback<V> extends CallbackAdapter<V> {

}

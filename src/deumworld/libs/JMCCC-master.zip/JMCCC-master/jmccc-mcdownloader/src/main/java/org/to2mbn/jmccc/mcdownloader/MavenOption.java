package org.to2mbn.jmccc.mcdownloader;

public enum MavenOption implements MinecraftDownloadOption {

	/**
	 * Update the snapshot artifacts.
	 */
	UPDATE_SNAPSHOTS;

}

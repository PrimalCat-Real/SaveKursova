package org.to2mbn.jmccc.mcdownloader.provider.forge;

public interface ForgeDownloadSource {

	String getForgeVersionListUrl();

	String getForgeMavenRepositoryUrl();

}

package org.to2mbn.jmccc.util;

public interface Builder<T> {

	T build();

}

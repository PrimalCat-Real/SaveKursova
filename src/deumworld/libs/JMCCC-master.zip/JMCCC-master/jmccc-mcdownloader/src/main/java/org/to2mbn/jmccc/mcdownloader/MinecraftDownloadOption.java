package org.to2mbn.jmccc.mcdownloader;

public interface MinecraftDownloadOption {
}
